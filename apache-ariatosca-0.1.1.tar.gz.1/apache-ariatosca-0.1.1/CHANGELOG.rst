0.1.1
-----

[ARIA-312] Validation of workflow and operation kwargs raise false alarms
[ARIA-301] Environment-marked dependencies are installed regardless of environment when installing from wheel
[ARIA-299] Resuming canceled execution with non-finished tasks fails
[ARIA-298] Test suite sometimes fails or freezes despite all tests passing
[ARIA-296] Process termination test fails on windows
[ARIA-287] New tox suite to make sure that Sphinx documentation generation isn't broken
[ARIA-202] Execution plugin assumes '/tmp' for temp directory on the local/remote machine


0.1.0
-----

 * Initial release.